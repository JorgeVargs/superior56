export const environment = {
  production: true,
  recaptcha: {
    siteKey: '6LcMAoEhAAAAAAYizCWUCsdMROd5tfRCQxXdiEin',
  },
};
