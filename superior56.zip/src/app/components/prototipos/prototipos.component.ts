import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prototipos',
  templateUrl: './prototipos.component.html',
  styleUrls: ['./prototipos.component.scss']
})
export class PrototiposComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
